let specialists = [];
let facilities = [];
let medicines = [];
let persons = [];

window.initZarzadzanie = async function () {

    if (!window.pywebview) {
        await new Promise(resolve => window.addEventListener("pywebviewready", resolve));
    }

    // --- ELEMENTY DOM ---

    const grid = document.querySelector(".manage-grid");

    const panelSpecialists = document.getElementById("panelSpecialists");
    const panelFacilities = document.getElementById("panelFacilities");
    const panelMedicines = document.getElementById("panelMedicines");
    const panelPersonManage = document.getElementById("panelPersonManage");

    const specialistsList = document.getElementById("specialistsList");
    const facilitiesList = document.getElementById("facilitiesList");
    const medicinesList = document.getElementById("medicinesList");

    const manageSelect = document.getElementById("managePersonSelect");
    const manageDesc = document.getElementById("managePersonDescription");
    const manageMedContainer = document.getElementById("managePersonMedicines");
    const saveManageBtn = document.getElementById("savePersonManageBtn");

    const popupOverlay = document.getElementById("popupOverlay");
    const popupTitle = document.getElementById("popupTitle");
    const popupInputs = document.getElementById("popupInputs");
    const popupCancel = document.getElementById("popupCancel");
    const popupSave = document.getElementById("popupSave");

    const btnReturn = document.getElementById("floatingReturnBtn");


    // --- PRZEŁĄCZANIE PANELI ---

    function showPanel(panel) {
        grid.classList.add("hidden");

        panelSpecialists.classList.add("hidden");
        panelFacilities.classList.add("hidden");
        panelMedicines.classList.add("hidden");
        panelPersonManage.classList.add("hidden");

        panel.classList.remove("hidden");
        btnReturn.classList.remove("hidden");

        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    btnReturn.onclick = () => {
        grid.classList.remove("hidden");

        panelSpecialists.classList.add("hidden");
        panelFacilities.classList.add("hidden");
        panelMedicines.classList.add("hidden");
        panelPersonManage.classList.add("hidden");

        btnReturn.classList.add("hidden");
        window.scrollTo({ top: 0, behavior: "smooth" });
    };


    // --- POPUP DODAWANIA / EDYCJI ---

    function openPopup(title, fields, onSave) {
        popupTitle.textContent = title;
        popupInputs.innerHTML = "";

        fields.forEach(f => {
            popupInputs.innerHTML += `
                <div class="field-group">
                    <label>${f.label}</label>
                    <input type="text" id="${f.id}"
                           placeholder="${f.placeholder || ''}"
                           value="${f.value || ''}">
                </div>
            `;
        });

        popupOverlay.classList.add("visible");

        popupSave.onclick = async () => {
            const values = {};
            fields.forEach(f => {
                values[f.id] = document.getElementById(f.id).value.trim();
            });

            await onSave(values);
            popupOverlay.classList.remove("visible");
            await reloadAll();
        };
    }

    popupCancel.onclick = () => popupOverlay.classList.remove("visible");


    // --- ŁADOWANIE DANYCH ---

    async function reloadAll() {
        specialists = await window.pywebview.api.get_specjalisci();
        facilities = await window.pywebview.api.get_placowki();
        medicines = await window.pywebview.api.get_leki();
        persons = await window.pywebview.api.get_podopieczni();

        // LICZNIKI
        document.getElementById("countSpecialists").textContent = specialists.length;
        document.getElementById("countFacilities").textContent = facilities.length;
        document.getElementById("countMedicines").textContent = medicines.length;
        document.getElementById("countPersons").textContent = persons.length;

        // -------- SPECJALIŚCI --------
        specialistsList.innerHTML = "";
        specialists.forEach(s => {
            const li = document.createElement("li");
            li.className = "list-row";

            li.innerHTML = `
                <span class="list-text">${s.role}: ${s.name}</span>
                <div class="list-actions">
                    <button class="edit-btn"><img src="../icons/edytuj.svg" alt=""></button>
                    <button class="delete-btn"><img src="../icons/usun.svg" alt=""></button>
                </div>
            `;

            // EDYCJA
            li.querySelector(".edit-btn").onclick = () => {
                openPopup(
                    "Edytuj specjalistę",
                    [
                        { id: "name", label: "Imię i nazwisko", value: s.name },
                        { id: "role", label: "Specjalizacja", value: s.role }
                    ],
                    async v => {
                        await window.pywebview.api.update_specjalista(s.id, v.name, v.role);
                    }
                );
            };

            // USUWANIE
            li.querySelector(".delete-btn").onclick = async () => {
                if (!confirm("Usunąć tego specjalistę?")) return;
                await window.pywebview.api.delete_specjalista(s.id);
                await reloadAll();
            };

            specialistsList.appendChild(li);
        });

        // -------- PLACÓWKI --------
        facilitiesList.innerHTML = "";
        facilities.forEach(f => {
            const li = document.createElement("li");
            li.className = "list-row";

            li.innerHTML = `
                <span class="list-text">${f.name} – ${f.address}</span>
                <div class="list-actions">
                    <button class="edit-btn"><img src="../icons/edytuj.svg" alt=""></button>
                    <button class="delete-btn"><img src="../icons/usun.svg" alt=""></button>
                </div>
            `;

            li.querySelector(".edit-btn").onclick = () => {
                openPopup(
                    "Edytuj placówkę",
                    [
                        { id: "name", label: "Nazwa", value: f.name },
                        { id: "address", label: "Adres", value: f.address }
                    ],
                    async v => {
                        await window.pywebview.api.update_placowka(f.id, v.name, v.address);
                    }
                );
            };

            li.querySelector(".delete-btn").onclick = async () => {
                if (!confirm("Usunąć tę placówkę?")) return;
                await window.pywebview.api.delete_placowka(f.id);
                await reloadAll();
            };

            facilitiesList.appendChild(li);
        });

        // -------- LEKI --------
        medicinesList.innerHTML = "";
        medicines.forEach(m => {
            const li = document.createElement("li");
            li.className = "list-row";

            li.innerHTML = `
                <span class="list-text">${m.name}</span>
                <div class="list-actions">
                    <button class="edit-btn"><img src="../icons/edytuj.svg" alt=""></button>
                    <button class="delete-btn"><img src="../icons/usun.svg" alt=""></button>
                </div>
            `;

            li.querySelector(".edit-btn").onclick = () => {
                openPopup(
                    "Edytuj lek",
                    [
                        { id: "name", label: "Nazwa leku", value: m.name }
                    ],
                    async v => {
                        await window.pywebview.api.update_lek(m.id, v.name);
                    }
                );
            };

            li.querySelector(".delete-btn").onclick = async () => {
                if (!confirm("Usunąć ten lek?")) return;
                await window.pywebview.api.delete_lek(m.id);
                await reloadAll();
            };

            medicinesList.appendChild(li);
        });

        // -------- PODOPIECZNI --------
        manageSelect.innerHTML = `<option value="">-- wybierz --</option>`;
        persons.forEach(p => {
            const opt = document.createElement("option");
            opt.value = p.id;
            opt.textContent = `${p.firstName} ${p.lastName}`;
            manageSelect.appendChild(opt);
        });

        manageMedContainer.innerHTML = "";
        medicines.forEach(m => {
            const label = document.createElement("label");
            const cb = document.createElement("input");
            cb.type = "checkbox";
            cb.value = m.id;
            label.appendChild(cb);
            label.append(" " + m.name);
            manageMedContainer.appendChild(label);
        });
    }


    // --- PODOPIECZNI ---

    manageSelect.onchange = () => {
        const id = manageSelect.value;
        const p = persons.find(x => x.id === id);

        if (!p) {
            manageDesc.value = "";
            manageMedContainer.querySelectorAll("input").forEach(cb => cb.checked = false);
            return;
        }

        manageDesc.value = p.description || "";

        manageMedContainer.querySelectorAll("input").forEach(cb => {
            cb.checked = p.medicines?.includes(cb.value);
        });
    };

    saveManageBtn.onclick = async () => {
        const id = manageSelect.value;
        if (!id) return alert("Wybierz podopiecznego");

        const description = manageDesc.value;
        const selectedMeds = Array.from(
            manageMedContainer.querySelectorAll("input:checked")
        ).map(cb => cb.value);

        await window.pywebview.api.update_podopiecznego(id, description, selectedMeds);
        alert("Zapisano zmiany");
        await reloadAll();
    };


    // --- KAFELKI (górne) ---

    document.getElementById("openSpecialists").onclick = () => showPanel(panelSpecialists);
    document.getElementById("openFacilities").onclick = () => showPanel(panelFacilities);
    document.getElementById("openMedicines").onclick = () => showPanel(panelMedicines);
    document.getElementById("openPersonManage").onclick = () => showPanel(panelPersonManage);


    // --- PRZYCISKI DODAWANIA W PANELACH ---

    document.getElementById("panelAddSpecialist").onclick = () => {
        openPopup(
            "Dodaj specjalistę",
            [
                { id: "name", label: "Imię i nazwisko", placeholder: "np. Jan Kowalski" },
                { id: "role", label: "Specjalizacja", placeholder: "np. Psycholog" }
            ],
            async v => {
                await window.pywebview.api.add_specjalista(v.name, v.role);
            }
        );
    };

    document.getElementById("panelAddFacility").onclick = () => {
        openPopup(
            "Dodaj placówkę",
            [
                { id: "name", label: "Nazwa", placeholder: "np. Szpital Rydygiera" },
                { id: "address", label: "Adres", placeholder: "np. Kraków, ul..." }
            ],
            async v => {
                await window.pywebview.api.add_placowka(v.name, v.address);
            }
        );
    };

    document.getElementById("panelAddMedicine").onclick = () => {
        openPopup(
            "Dodaj lek",
            [
                { id: "name", label: "Nazwa leku", placeholder: "np. Ibuprom" }
            ],
            async v => {
                await window.pywebview.api.add_lek(v.name);
            }
        );
    };


    // --- START ---

    await reloadAll();
};
