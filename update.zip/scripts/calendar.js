(function () {

    /* ============================
        NAZWY MIESIĘCY
    ============================ */
    const monthNamesPl = [
        "styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec",
        "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"
    ];

    const today = new Date();
    const minMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);

    let viewYear = today.getFullYear();
    let viewMonth = today.getMonth();

    function sameDate(y, m, d, dateObj) {
        return (
            y === dateObj.getFullYear() &&
            m === dateObj.getMonth() &&
            d === dateObj.getDate()
        );
    }


    /* ============================
        WYDARZENIA
    ============================ */

    let calendarEvents = [];

    // Pobranie wydarzeń z backendu
    window.initCalendarEvents = async function () {
        if (!window.pywebview) return;

        try {
            calendarEvents = await window.pywebview.api.get_events();
        } catch (e) {
            console.error("Błąd pobierania wydarzeń:", e);
        }
    };

    // Zapis nowego wydarzenia
    async function saveEvent(eventData) {
        if (!window.pywebview) return;

        await window.pywebview.api.add_event(eventData);
        calendarEvents = await window.pywebview.api.get_events();
    }


    /* ============================================================
       SORTOWANIE WYDARZEŃ I RENDER W KOMÓRKACH
    ============================================================ */

    function renderEventsInCalendar(gridEl, year, month) {
        // 1. Filtrowanie wydarzeń z danego miesiąca
        const monthEvents = calendarEvents.filter(ev => {
            const d = new Date(ev.date);
            return d.getFullYear() === year && d.getMonth() === month;
        });

        // 2. Grupowanie po dniu
        const eventsByDay = {};
        monthEvents.forEach(ev => {
            const d = new Date(ev.date);
            const day = d.getDate();
            if (!eventsByDay[day]) eventsByDay[day] = [];
            eventsByDay[day].push(ev);
        });

        // 3. Sortowanie w obrębie dnia po godzinie
        Object.keys(eventsByDay).forEach(day => {
            eventsByDay[day].sort((a, b) => new Date(a.date) - new Date(b.date));
        });

        // 4. Renderowanie
        Object.keys(eventsByDay).forEach(dayStr => {
            const day = parseInt(dayStr, 10);
            const list = eventsByDay[day];

            // Obliczamy index komórki w siatce (pon–nd, 6x7)
            const tempDate = new Date(year, month, day);
            const index = (tempDate.getDay() === 0 ? 6 : tempDate.getDay() - 1) + (day - 1);

            const cell = gridEl.children[index];
            if (!cell) return;

            const container = document.createElement("div");
            container.classList.add("event-list");

            list.forEach(ev => {
                const d = new Date(ev.date);
                const time = d.toLocaleTimeString("pl-PL", {
                    hour: "2-digit",
                    minute: "2-digit"
                });

                const item = document.createElement("div");
                item.classList.add("event-item");

                if (ev.type === "visit_specialist") item.classList.add("event-blue");
                if (ev.type === "visit_facility") item.classList.add("event-red");
                if (ev.type === "dps_event") item.classList.add("event-gray");

                const personText = ev.person ? `${ev.person} • ` : "";

                item.innerHTML = `
                    <div class="event-time">${time}</div>
                    <div class="event-text">${personText}${ev.description}</div>
                `;

                // Kliknięcie – szczegóły wydarzenia
                item.onclick = () => showEventDetails(ev);

                container.appendChild(item);
            });

            cell.appendChild(container);
        });
    }


    /* ============================================================
       MODAL SZCZEGÓŁÓW WYDARZENIA
    ============================================================ */

    window.showEventDetails = function (ev) {
        const modal = document.getElementById("eventDetailsOverlay");
        if (!modal) return;

        const typeEl   = document.getElementById("detailsType");
        const personEl = document.getElementById("detailsPerson");
        const descEl   = document.getElementById("detailsDesc");
        const dateEl   = document.getElementById("detailsDate");
        const timeEl   = document.getElementById("detailsTime");
        const delBtn   = document.getElementById("detailsDelete");
        const closeBtn = document.getElementById("detailsClose");

        if (!typeEl || !personEl || !descEl || !dateEl || !timeEl || !delBtn || !closeBtn) {
            console.warn("Brak elementów modala szczegółów wydarzenia");
            return;
        }

        typeEl.textContent = readableType(ev.type);
        personEl.textContent = ev.person || "—";
        descEl.textContent = ev.description;

        const d = new Date(ev.date);
        dateEl.textContent = d.toLocaleDateString("pl-PL");
        timeEl.textContent = d.toLocaleTimeString("pl-PL", {
            hour: "2-digit",
            minute: "2-digit"
        });

        // Usuwanie wydarzenia
        delBtn.onclick = async () => {
            try {
                if (window.pywebview && window.pywebview.api.delete_event) {
                    await window.pywebview.api.delete_event(ev.id);
                    await window.initCalendarEvents();
                    window.initCalendar();
                } else {
                    console.error("delete_event nie jest dostępne w API pywebview");
                }
            } catch (e) {
                console.error("Błąd usuwania wydarzenia:", e);
            }
            modal.classList.remove("visible");
        };

        // Zamknięcie
        closeBtn.onclick = () => {
            modal.classList.remove("visible");
        };

        modal.classList.add("visible");
    };

    function readableType(t) {
        switch (t) {
            case "visit_specialist": return "Wizyta u specjalisty";
            case "visit_facility":   return "Wizyta w placówce";
            case "dps_event":        return "Wydarzenie w DPS";
            default:                 return t;
        }
    }


    /* ============================
        RENDER KALENDARZA
    ============================ */

    function renderCalendar(titleEl, gridEl) {
        if (!gridEl || !titleEl) return;

        titleEl.textContent = `${monthNamesPl[viewMonth]} ${viewYear}`;
        gridEl.innerHTML = "";

        const firstDay     = new Date(viewYear, viewMonth, 1);
        const daysInMonth  = new Date(viewYear, viewMonth + 1, 0).getDate();
        const prevMonthDays = new Date(viewYear, viewMonth, 0).getDate();

        let startDay = firstDay.getDay();
        startDay = startDay === 0 ? 6 : startDay - 1;

        const totalCells  = 42;
        let dayCounter    = 1;
        let nextMonthDay  = 1;

        for (let i = 0; i < totalCells; i++) {
            const cell = document.createElement("div");
            cell.classList.add("calendar-day");

            let displayDay;
            let isOtherMonth = false;

            if (i < startDay) {
                displayDay = prevMonthDays - startDay + 1 + i;
                isOtherMonth = true;
            } else if (dayCounter <= daysInMonth) {
                displayDay = dayCounter;

                if (sameDate(viewYear, viewMonth, dayCounter, today)) {
                    cell.classList.add("today");
                }

                dayCounter++;
            } else {
                displayDay = nextMonthDay++;
                isOtherMonth = true;
            }

            if (isOtherMonth) cell.classList.add("other-month");

            const span = document.createElement("span");
            span.textContent = displayDay;
            cell.appendChild(span);

            gridEl.appendChild(cell);
        }

        renderEventsInCalendar(gridEl, viewYear, viewMonth);
    }


    /* ============================
        GŁÓWNA FUNKCJA KALENDARZA
    ============================ */

    window.initCalendar = function () {
        const titleEl = document.getElementById("calendarTitle");
        const gridEl  = document.getElementById("calendarGrid");
        const prevBtn = document.getElementById("prevMonthBtn");
        const nextBtn = document.getElementById("nextMonthBtn");
        const todayBtn = document.getElementById("todayBtn");

        if (!titleEl || !gridEl) {
            console.warn("Brak elementów kalendarza!");
            return;
        }

        viewYear  = today.getFullYear();
        viewMonth = today.getMonth();

        renderCalendar(titleEl, gridEl);

        if (prevBtn)
            prevBtn.onclick = () => {
                let newYear  = viewYear;
                let newMonth = viewMonth - 1;

                if (newMonth < 0) {
                    newMonth = 11;
                    newYear--;
                }

                const candidate = new Date(newYear, newMonth, 1);
                if (
                    candidate.getFullYear() < minMonthDate.getFullYear() ||
                    (candidate.getFullYear() === minMonthDate.getFullYear() &&
                        candidate.getMonth() < minMonthDate.getMonth())
                ) return;

                viewYear  = newYear;
                viewMonth = newMonth;
                renderCalendar(titleEl, gridEl);
            };

        if (nextBtn)
            nextBtn.onclick = () => {
                viewMonth++;
                if (viewMonth > 11) {
                    viewMonth = 0;
                    viewYear++;
                }
                renderCalendar(titleEl, gridEl);
            };

        if (todayBtn)
            todayBtn.onclick = () => {
                viewYear  = today.getFullYear();
                viewMonth = today.getMonth();
                renderCalendar(titleEl, gridEl);
            };
    };


    /* ============================
        MODAL – DODAWANIE WYDARZENIA
    ============================ */

    window.initCalendarModal = async function () {
        const btn       = document.getElementById("openAddPopup");
        const overlay   = document.getElementById("eventOverlay");

        const typeSelect      = document.getElementById("eventType");
        const personContainer = document.getElementById("eventPersonContainer");
        const personSelect    = document.getElementById("eventPerson");

        const cancelBtn = document.getElementById("eventCancelBtn");
        const saveBtn   = document.getElementById("eventSaveBtn");

        if (!btn || !overlay || !typeSelect || !personContainer || !personSelect || !cancelBtn || !saveBtn) {
            console.warn("Brak elementów modala wydarzenia.");
            return;
        }

        // Pobieramy podopiecznych
        let podopieczni = [];
        if (window.pywebview && window.pywebview.api.get_podopieczni) {
            podopieczni = await window.pywebview.api.get_podopieczni();
        }

        // Wypełniamy select listą podopiecznych
        personSelect.innerHTML = "";
        podopieczni.forEach(p => {
            const opt = document.createElement("option");
            const fullName = `${p.firstName} ${p.lastName}`;
            opt.value = fullName;
            opt.textContent = fullName;
            personSelect.appendChild(opt);
        });

        // Pokaż / ukryj wybór podopiecznego
        typeSelect.onchange = () => {
            if (
                typeSelect.value === "visit_specialist" ||
                typeSelect.value === "visit_facility"
            ) {
                personContainer.style.display = "block";
            } else {
                personContainer.style.display = "none";
            }
        };
        // Ustaw początkowy stan
        typeSelect.onchange();

        // Otwieranie okna
        btn.onclick = () => overlay.classList.add("visible");

        // Zamknięcie
        cancelBtn.onclick = () => overlay.classList.remove("visible");

        // Zapis wydarzenia
        saveBtn.onclick = async () => {
            const type = typeSelect.value;
            const description = document.getElementById("eventDescription").value.trim();
            const date = document.getElementById("eventDate").value;
            const time = document.getElementById("eventTime").value;

            const person =
                (type === "visit_specialist" || type === "visit_facility")
                    ? personSelect.value
                    : null;

            if (!description || !date || !time) {
                alert("Wypełnij wszystkie pola!");
                return;
            }

            await saveEvent({
                type,
                description,
                person,
                date: `${date}T${time}`
            });

            overlay.classList.remove("visible");

            window.initCalendar();
        };
    };


    /* ============================
        AUTO-INIT PO ZAŁADOWANIU STRONY
    ============================ */

    document.addEventListener("DOMContentLoaded", async () => {
        // lekkie opóźnienie – żeby router zdążył wstawić stronę
        setTimeout(async () => {
            const calendarExists = document.getElementById("calendarGrid") !== null;

            if (calendarExists) {
                await window.initCalendarEvents();
                window.initCalendar();
                window.initCalendarModal();
            } else {
                console.log("Kalendarz nie występuje na tej stronie – pomijam init");
            }
        }, 150);
    });

})();
