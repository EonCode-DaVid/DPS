window.initSettings = async function () {

    const localVersionEl = document.getElementById("localVersion");
    const latestVersionEl = document.getElementById("latestVersion");
    const updateBtn = document.getElementById("updateButton");
    const statusEl = document.getElementById("updateStatus");

    if (!window.pywebview) {
        localVersionEl.textContent = "Brak API";
        latestVersionEl.textContent = "Brak API";
        return;
    }

    // Pobieranie wersji
    const localVersion = await window.pywebview.api.get_local_version();
    const latestVersion = await window.pywebview.api.get_latest_version();

    localVersionEl.textContent = localVersion;
    latestVersionEl.textContent = latestVersion || "Błąd";

    updateBtn.onclick = async () => {

        statusEl.textContent = "Sprawdzam...";
        statusEl.className = "update-status update-loading";

        const result = await window.pywebview.api.update_app();

        if (result === "NO_UPDATE") {
            statusEl.textContent = "Masz najnowszą wersję 🎉";
            statusEl.className = "update-status update-ok";
            return;
        }

        if (result === "OK") {
            statusEl.textContent = "Pobrano aktualizację! Uruchom aplikację ponownie.";
            statusEl.className = "update-status update-ok";
            return;
        }

        statusEl.textContent = result;
        statusEl.className = "update-status update-error";
    };
};
