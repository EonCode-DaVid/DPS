let podopieczniListEl;
let pendingDeleteId = null;

window._podopieczniCache = [];
window._medCache = [];

/* ============================================================
   ELEMENTY DO ROZMYWANIA (search + add button)
============================================================ */

let blurTargets = [];

// Funkcja nakładająca blur
function applyBlur() {
    blurTargets.forEach(el => el && el.classList.add("blur-when-modal"));
}

// Funkcja zdejmująca blur
function removeBlur() {
    blurTargets.forEach(el => el && el.classList.remove("blur-when-modal"));
}


/* ============================================================
   MODAL — USUWANIE
============================================================ */

window.deletePersonConfirm = function (id) {
    pendingDeleteId = id;
    document.getElementById("deleteOverlay").classList.add("visible");
    applyBlur();
};

window.initDeleteModal = function () {
    const overlay = document.getElementById("deleteOverlay");
    const cancelBtn = document.getElementById("deleteCancelBtn");
    const confirmBtn = document.getElementById("deleteConfirmBtn");

    cancelBtn.onclick = () => {
        pendingDeleteId = null;
        overlay.classList.remove("visible");
        removeBlur();
    };

    confirmBtn.onclick = async () => {
        if (!pendingDeleteId) return;

        await window.pywebview.api.delete_podopiecznego(pendingDeleteId);

        pendingDeleteId = null;
        overlay.classList.remove("visible");
        removeBlur();

        await loadPodopieczni();
    };
};


/* ============================================================
   MODAL — SZCZEGÓŁY PODOPIECZNEGO
============================================================ */

window.showPersonDetails = function (id) {
    const p = window._podopieczniCache.find(x => x.id === id);
    if (!p) return;

    const overlay = document.getElementById("detailsOverlay");

    document.getElementById("detailsName").textContent =
        p.firstName + " " + p.lastName;

    document.getElementById("detailsAge").textContent = calculateAge(p.birthDate);
    document.getElementById("detailsBirth").textContent = p.birthDate;

    document.getElementById("detailsDescription").textContent =
        p.description && p.description.length > 0 ? p.description : "Brak opisu";

    // Leki
    const medsList = document.getElementById("detailsMedicines");
    medsList.innerHTML = "";

    if (!p.medicines || p.medicines.length === 0) {
        medsList.innerHTML = "<li>Brak</li>";
    } else {
        p.medicines.forEach(mId => {
            const med = window._medCache.find(x => x.id === mId);
            const li = document.createElement("li");
            li.textContent = med ? med.name : "Nieznany lek";
            medsList.appendChild(li);
        });
    }

    document.getElementById("detailsClose").onclick = () => {
        overlay.classList.remove("visible");
        removeBlur();
    };

    overlay.classList.add("visible");
    applyBlur();
};


/* ============================================================
   INICJALIZACJA STRONY
============================================================ */

window.initPodopieczni = async function () {
    if (!window.pywebview) {
        await new Promise(resolve =>
            window.addEventListener("pywebviewready", resolve)
        );
    }

    podopieczniListEl = document.getElementById("podopieczniList");

    // Przyciski do rozmywania
    blurTargets = [
        document.getElementById("searchFloating"),
        document.getElementById("openAddPopup")
    ];

    const openBtn = document.getElementById("openAddPopup");
    const overlay = document.getElementById("popupOverlay");

    const saveBtn = document.getElementById("saveBtn");
    const cancelBtn = document.getElementById("cancelBtn");

    const inputFirstName = document.getElementById("inputFirstName");
    const inputLastName = document.getElementById("inputLastName");
    const inputBirthDate = document.getElementById("inputBirthDate");

    /* === Dodawanie === */

    openBtn.onclick = () => {
        overlay.classList.add("visible");
        applyBlur();

        inputFirstName.value = "";
        inputLastName.value = "";
        inputBirthDate.value = "";
    };

    cancelBtn.onclick = () => {
        overlay.classList.remove("visible");
        removeBlur();
    };

    saveBtn.onclick = async () => {
        const firstName = inputFirstName.value.trim();
        const lastName = inputLastName.value.trim();
        const birthDate = inputBirthDate.value.trim();

        if (!firstName || !lastName || !birthDate)
            return alert("Wypełnij wszystkie pola");

        await window.pywebview.api.add_podopiecznego(firstName, lastName, birthDate);

        overlay.classList.remove("visible");
        removeBlur();
        await loadPodopieczni();
    };

    // Cache leków
    window._medCache = await window.pywebview.api.get_leki();

    // Obsługa wyszukiwarki
    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
        searchInput.oninput = () => filterPodopieczni();
    }

    await loadPodopieczni();
    window.initDeleteModal();
};


/* ============================================================
   FUNKCJE POMOCNICZE
============================================================ */

function calculateAge(dateStr) {
    const birth = new Date(dateStr);
    const today = new Date();

    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;

    return age;
}


/* ============================================================
   FILTROWANIE PODOPIECZNYCH
============================================================ */

function filterPodopieczni() {
    const q = document.getElementById("searchInput").value.toLowerCase().trim();
    if (!q) return renderPodopieczni(window._podopieczniCache);

    const filtered = window._podopieczniCache.filter(p => {
        const age = calculateAge(p.birthDate) + "";

        return (
            p.firstName.toLowerCase().includes(q) ||
            p.lastName.toLowerCase().includes(q) ||
            (p.description && p.description.toLowerCase().includes(q)) ||
            p.birthDate.includes(q) ||
            age.includes(q)
        );
    });

    renderPodopieczni(filtered);
}


/* ============================================================
   RENDER LISTY
============================================================ */

function renderPodopieczni(list) {
    podopieczniListEl.innerHTML = "";

    list.forEach(person => {
        const age = calculateAge(person.birthDate);

        const card = document.createElement("div");
        card.className = "podopieczny-card";

        card.onclick = () => showPersonDetails(person.id);

        card.innerHTML = `
            <div class="podopieczny-left">
                <img src="../icons/podopieczny.svg" class="podopieczny-icon">
                <div class="podopieczny-info">
                    <span class="podopieczny-name">${person.firstName} ${person.lastName}</span>
                    <span class="podopieczny-age">Wiek: ${age} lat</span>
                </div>
            </div>

            <button class="delete-btn"
                onclick="event.stopPropagation(); deletePersonConfirm('${person.id}')">
                Usuń
            </button>
        `;

        podopieczniListEl.appendChild(card);
    });
}

async function loadPodopieczni() {
    const data = await window.pywebview.api.get_podopieczni();
    window._podopieczniCache = data;

    renderPodopieczni(data);
}
