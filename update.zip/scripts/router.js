document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".btn[data-page]");
    const content = document.getElementById("content");

    async function loadPage(page) {
        try {
            // Zamykanie popupów jeśli były otwarte
            document.body.classList.remove("popup-open");

            const response = await fetch(`pages/${page}.html`);

            if (!response.ok) {
                content.innerHTML = `<p style="padding:20px;color:red;">Nie znaleziono strony: ${page}</p>`;
                return;
            }

            const html = await response.text();
            content.innerHTML = html;

            // Podświetlenie menu
            buttons.forEach(btn => {
                btn.classList.toggle("active", btn.dataset.page === page);
            });

            // ======= INICJALIZACJE STRON =======
            switch (page) {

                case "kalendarz":
                    console.log("Init kalendarza…");

                    if (typeof window.initCalendarEvents === "function")
                        await window.initCalendarEvents();

                    if (typeof window.initCalendar === "function")
                        window.initCalendar();

                    if (typeof window.initCalendarModal === "function")
                        window.initCalendarModal();

                    break;

                case "podopieczni":
                    console.log("Init podopiecznych…");
                    if (typeof window.initPodopieczni === "function")
                        window.initPodopieczni();
                    break;

                case "zarzadzanie":
                    console.log("Init zarządzania…");
                    if (typeof window.initZarzadzanie === "function")
                        window.initZarzadzanie();
                    break;
            }

            // Scroll na górę
            window.scrollTo({ top: 0, behavior: "smooth" });

        } catch (err) {
            content.innerHTML = `<p style="padding:20px;color:red;">Błąd wczytywania strony.</p>`;
            console.error(err);
        }
    }

    // Obsługa kliknięć menu
    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            loadPage(btn.dataset.page);
        });
    });

    // Domyślnie ładujemy podopiecznych
    loadPage("podopieczni");
});
